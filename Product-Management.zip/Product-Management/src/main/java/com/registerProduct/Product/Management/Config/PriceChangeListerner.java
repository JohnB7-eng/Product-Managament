package com.registerProduct.Product.Management.Config;

import com.registerProduct.Product.Management.Entity.Product;
import com.registerProduct.Product.Management.Repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class PriceChangeListerner {

    @Autowired
    public ProductRepository productRepository;

    @KafkaListener(topics = "price-change-topic", groupId = "price-change-group")
    public void listen(String message) {
        // Parse the message to extract product ID and new price
        // For simplicity, let's assume the message format is "Product ID: 1, New Price: 100.00"
        String[] parts = message.split(", ");
        String productIdPart = parts[0];
        String newPricePart = parts[1];

        String productIdStr = productIdPart.split(": ")[1];
        Long productId = Long.parseLong(productIdStr);
        Double newPrice = Double.parseDouble(newPricePart.split(": ")[1]);

        Product product = productRepository.findById(productId).orElse(null);
        if (product != null) {
            product.setPrice(newPrice);
            productRepository.save(product);
        }
    }

}

