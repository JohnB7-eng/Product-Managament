import React, { useState } from "react";
import ProductDetails from "./ProductDetails";



const App = () => {
  const [products, setProducts] = useState([
    { id: 1, name: 'Callaway Raz', img: 'Cally.jpeg', price: 699 },
    { id: 2, name: 'Taylormade Sim', img: 'Tally.jpeg', price: 999 },
    { id: 3, name: 'Ping 425', img: 'Ping.jpeg', price: 749 },
  ]);

  const handleUpdatePrice = (productId, newPrice) => {
    const updatedProducts = products.map((product) => {
      if (product.id === productId) {
        return { ...product, price: newPrice };
      }
      return product;
    });
    setProducts(updatedProducts);
  };

  return (
    <div>
      <h1> Lowes </h1>
      <div style={{ display: 'flex' }}>
        {products.map((product) => (
          <ProductDetails
            key={product.id}
            product={product}
            onUpdatePrice={handleUpdatePrice}
          />
        ))}
      </div>
    </div>
  );
};

export default App
