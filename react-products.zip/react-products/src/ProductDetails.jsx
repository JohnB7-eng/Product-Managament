import React, { useState } from "react";


const ProductDetails = ({ product, onUpdatePrice }) => {
    const [newPrice, setNewPrice] = useState('');
  
    const handleChange = (event) => {
      setNewPrice(event.target.value);
    };
  
    const handleSubmit = (event) => {
      event.preventDefault();
      onUpdatePrice(product.id, parseFloat(newPrice));
      setNewPrice('');
    };
  
    return (
      <div>
        <h2>Product</h2>
        <div>
          <img src={product.img} />
          <h3>{product.name}</h3>
          <p>Price: ${product.price}</p>
          <form onSubmit={handleSubmit}>
            <label>
              New Price:
              <input
                type="number"
                value={newPrice}
                onChange={handleChange}
                step="0.01"
                min="0"
                required
              />
            </label>
            <button type="submit">Update Price</button>
          </form>
        </div>
      </div>
    );
  };

export default ProductDetails
